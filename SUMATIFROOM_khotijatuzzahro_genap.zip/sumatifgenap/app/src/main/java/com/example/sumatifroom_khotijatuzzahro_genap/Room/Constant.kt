package com.example.sumatifroom_khotijatuzzahro_genap.Room

class Constant {
    companion object{
        const val TYPE_READ = 0
        const val TYPE_CREATE = 1
        const val TYPE_UPDATE= 2
    }
}